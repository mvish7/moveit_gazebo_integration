// ROS
#include <ros/ros.h>

// MoveIt!
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/move_group_interface/move_group_interface.h>

// TF2
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>



void addCollisionObjects(moveit::planning_interface::PlanningSceneInterface& planning_scene_interface)
{
  
  // Creating Environment

std::vector<moveit_msgs::CollisionObject> collision_objects;
collision_objects.resize(2);
Eigen::Vector3d b(0.001, 0.001, 0.001);

collision_object.id = "wall";
shapes::Mesh* m = shapes::createMeshFromResource("package://",b);

}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "panda_arm_pick_place");
  ros::NodeHandle nh;
  ros::AsyncSpinner spinner(1);
  spinner.start();

  ros::WallDuration(1.0).sleep();
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
  moveit::planning_interface::MoveGroupInterface group("panda_arm");
  group.setPlanningTime(45.0);

  addCollisionObjects(planning_scene_interface);

  // Wait a bit for ROS things to initialize
  ros::WallDuration(1.0).sleep();

  //pick(group);
}