#include <ros/ros.h>

#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>



void openGripper(trajectory_msgs::JointTrajectory& posture)
{
  
  /* Add both finger joints of panda robot. */
  posture.joint_names.resize(2);
  posture.joint_names[0] = "panda_finger_joint1";
  posture.joint_names[1] = "panda_finger_joint2";

  /* Set them as open, wide enough for the object to fit. */
  posture.points.resize(1);
  posture.points[0].positions.resize(2);
  posture.points[0].positions[0] = 0.04;
  posture.points[0].positions[1] = 0.04;
  posture.points[0].time_from_start = ros::Duration(0.5);

}


void closedGripper(trajectory_msgs::JointTrajectory& posture)
{
  /* Add both finger joints of panda robot. */
  posture.joint_names.resize(2);
  posture.joint_names[0] = "panda_finger_joint1";
  posture.joint_names[1] = "panda_finger_joint2";

  /* Set them as closed. */
  posture.points.resize(1);
  posture.points[0].positions.resize(2);
  posture.points[0].positions[0] = 0.00;
  posture.points[0].positions[1] = 0.00;
  posture.points[0].time_from_start = ros::Duration(0.5);
  
}



void pick(moveit::planning_interface::MoveGroupInterface& move_group)
{
    std::vector<moveit_msgs::Grasp> grasps;
    grasps.resize(1);

//setting pre grasp pose i.e ask robot arm to go to this position and wait before approaching the object
    grasps[0].grasp_pose.header.frame_id = "panda_link0";
    tf2::Quaternion orientation;

    orientation.setRPY(-M_PI / 4, -M_PI / 2, -M_PI / 4);

    grasps[0].grasp_pose.pose.orientation = tf2::toMsg(orientation);
    grasps[0].grasp_pose.pose.position.x = 0.455524;
    grasps[0].grasp_pose.pose.position.y = 0.267652;
    grasps[0].grasp_pose.pose.position.z = 0.217253;

 //setting pre grasp approach i.e asking robot to approach the object before trying to grasp it   

     grasps[0].pre_grasp_approach.direction.header.frame_id = "panda_link0";
  /* Direction is set as positive x axis */
     grasps[0].pre_grasp_approach.direction.vector.y = 1.0;
     grasps[0].pre_grasp_approach.min_distance = 0.095;
     grasps[0].pre_grasp_approach.desired_distance = 0.115; 

 // Setting post-grasp retreat 

     grasps[0].post_grasp_retreat.direction.header.frame_id = "panda_link0";
  /* Direction is set as negative y axis */
     grasps[0].post_grasp_retreat.direction.vector.y = -1.0;
     grasps[0].post_grasp_retreat.min_distance = 0.1;
     grasps[0].post_grasp_retreat.desired_distance = 0.25;

//setting posture of end effector before grasp

     openGripper(grasps[0].pre_grasp_posture);

//setting posture of eef during grasp

     closedGripper(grasps[0].grasp_posture);

     move_group.pick("", grasps);     

}




int main(int argc, char** argv)
{
  ros::init(argc, argv, "moveit_interface");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(1);
  spinner.start();

  ros::WallDuration(1.0).sleep();
 
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;
  moveit::planning_interface::MoveGroupInterface group("panda_arm");
  group.setPlanningTime(45.0);


  // Wait a bit for ROS things to initialize

   ros::WallDuration(1.0).sleep();

    pick(group);

}