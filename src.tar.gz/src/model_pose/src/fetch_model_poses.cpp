#include "ros/ros.h"
#include "gazebo_msgs/GetModelState.h"

const std::string model_name;
const std::string relative_entity_name;

float pose [7];

int main(int argc, char **argv)
{
  ros::init(argc, argv, "fetch_model_poses");
  ros::NodeHandle n;
  ros::ServiceClient client = n.serviceClient<gazebo_msgs::GetModelState>("/gazebo/get_model_state");

  gazebo_msgs::GetModelState getmodelstate;
  getmodelstate.request.model_name="kaffee_4";

  if (client.call(getmodelstate))
  {
      
      ROS_INFO("position_x=%f", getmodelstate.response.pose.position.x);
      ROS_INFO("position_y=%f", getmodelstate.response.pose.position.y);
      ROS_INFO("position_z=%f", getmodelstate.response.pose.position.z);
      ROS_INFO("orientation_x=%f", getmodelstate.response.pose.orientation.x);
      ROS_INFO("orientation_y=%f", getmodelstate.response.pose.orientation.y);
      ROS_INFO("orientation_z=%f", getmodelstate.response.pose.orientation.z);
      ROS_INFO("orientation_w=%f", getmodelstate.response.pose.orientation.w);

      pose[0]= getmodelstate.response.pose.position.x;
      pose[1]= getmodelstate.response.pose.position.y;
      pose[2]= getmodelstate.response.pose.position.z;
      pose[3]= getmodelstate.response.pose.orientation.x;
      pose[4]= getmodelstate.response.pose.orientation.y;
      pose[5]= getmodelstate.response.pose.orientation.z;
      pose[6]= getmodelstate.response.pose.orientation.w;
      
      
  }

  else
  {
      ROS_INFO ("FAILED");

  }

  return 0;
}
