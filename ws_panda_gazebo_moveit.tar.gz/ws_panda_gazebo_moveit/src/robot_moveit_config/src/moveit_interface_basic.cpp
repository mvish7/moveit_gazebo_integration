#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "moveit_interface");
  ros::NodeHandle node_handle;
  ros::AsyncSpinner spinner(1);
  spinner.start();

  static const std::string PLANNING_GROUP = "panda_arm";

  moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);

   //setting up movegroup class
   moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

   const robot_state::JointModelGroup* joint_model_group =
   move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);

   move_group.setPlanningTime(15);

   tf2::Quaternion orientation;
  // orientation to approach object from x direction(outword from the screen, pointing to user ) 
  //orientation.setRPY(-M_PI / 2, -M_PI / 4, -M_PI / 2);

    // this goes near over to pick object from y direction
    //orientation.setRPY(-M_PI / 4, -M_PI / 4, -M_PI / 4);

 
   orientation.setRPY(-M_PI / 4, -M_PI/2 , -M_PI /4);


  // Planning to a Pose goal
  // We can plan a motion for this group to a desired pose for the
  // end-effector.
  
  geometry_msgs::Pose target_pose1;
  //target_pose1.orientation.x = -0.000013;
  //target_pose1.orientation.y = 0.0;
  //target_pose1.orientation.z = 0.0;
  //target_pose1.orientation.w = 1.0;
  target_pose1.orientation = tf2::toMsg(orientation);
  target_pose1.position.x = 0.516284;
  target_pose1.position.y = 0.352037;
  target_pose1.position.z = 0.850215;
  //move_group.setApproximateJointValueTarget(target_pose1, "panda_link7");
  move_group.setPoseTarget(target_pose1);
   

   //call the planer to plan the myplan
   moveit::planning_interface::MoveGroupInterface::Plan my_plan;

   //moving to pose goal
   move_group.move();

   ros::shutdown();
 return 0;
}
